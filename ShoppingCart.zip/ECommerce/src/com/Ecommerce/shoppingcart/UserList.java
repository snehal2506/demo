package com.Ecommerce.shoppingcart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserList {
	
		//static String userName;
		//static String password;
		public  void  userList(String userName,String password) throws SQLException 
		{
			Connection con=null;
			PreparedStatement ps2=null;
			ResultSet rs2=null;
			
			try {
				ConnectionTest connectionTest=new ConnectionTest();
				con=connectionTest.getConnectionDetails();
				double total=0;
				
				//System.out.println("you can add");
				 ps2=con.prepareStatement("select * from "+ userName +" order by  name asc");
				 //ps2=con.prepareStatement("select * from "+userName+"");
				//ps2.setString(1, x);
				 rs2=ps2.executeQuery();
				System.out.printf("%20s %20s %20s %20s %20s ", "prouductId", "description", "price", "name", "quantity");
						while(rs2.next())
						{
							System.out.println();
						    System.out.println("------------------------------------------------------------------------------------------------------------------------------");
							System.out.format("%20d %20s %20s %20s %20d", rs2.getInt(1), rs2.getString(2), rs2.getDouble(3), 
							rs2.getString(4), rs2.getInt(5));
							System.out.println();
							total=total + rs2.getInt(5) * rs2.getDouble(3);
							
						}
					System.out.println("Total value in Cart is: "+total);
					PreparedStatement ps3=con.prepareStatement("update productdetails  p inner join "+ userName +" s on p.prouductId=s.prouductId set p.quantity = (p.quantity-s.quantity);");
					int i=ps3.executeUpdate();
					System.out.println(i);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				con.close();
				ps2.close();
				rs2.close();
			}
		}
	}

