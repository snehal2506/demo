package com.Ecommerce.shoppingcart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Admin {
	public static void  displayAdmin() throws SQLException 
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ConnectionTest connectionTest=new ConnectionTest();
			con=connectionTest.getConnectionDetails();
			
			ps=con.prepareStatement("select * from productdetails");
			 rs=ps.executeQuery();
			 
					System.out.printf("%20s %20s %20s %20s %20s ", "prouductId", "description", "price", "name", "quantity");
					while(rs.next())
					{
						System.out.println();
					    System.out.println("------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%20d %20s %20s %20s %20d", rs.getInt(1), rs.getString(2), rs.getDouble(3), 
						rs.getString(4), rs.getInt(5));
						System.out.println();
					}
					
					
			}
			
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			ps.close();
			rs.close();
		}
	}
	
	public static void  displayUserDetails(String userName,String password) throws SQLException 
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ConnectionTest connectionTest=new ConnectionTest();
			con=connectionTest.getConnectionDetails();
			
			ps=con.prepareStatement("select * from "+ userName +"");
			 rs=ps.executeQuery();
			 
					System.out.printf("%20s %20s %20s %20s %20s ", "prouductId", "description", "price", "name", "quantity");
					while(rs.next())
					{
						System.out.println();
					    System.out.println("------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%20d %20s %20s %20s %20d", rs.getInt(1), rs.getString(2), rs.getDouble(3), 
						rs.getString(4), rs.getInt(5));
						System.out.println();
					}
					
					
			}
			
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			ps.close();
			rs.close();
		}
	}
	
	public static void displayUserToAdmin() throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ConnectionTest connectionTest = new ConnectionTest();
			con = connectionTest.getConnectionDetails();
			ps = con.prepareStatement("SELECT * FROM shoppingcart.userdetails;");
			rs = ps.executeQuery();
			System.out.printf("%20s %20s ", "UserName", "Password");
			while(rs.next())
			{
				System.out.println();
			    System.out.println("---------------------------------------------------");
				System.out.format("%20s %20s ", rs.getString(1), rs.getString(2));
				System.out.println();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.close();
			ps.close();
			rs.close();
		}
	}
}
