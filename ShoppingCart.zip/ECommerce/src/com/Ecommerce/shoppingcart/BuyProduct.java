package com.Ecommerce.shoppingcart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BuyProduct {
	static String userName;
	static String password;
	public static void  buyProduct(String userName,String password) throws SQLException 
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ConnectionTest connectionTest=new ConnectionTest();
			con=connectionTest.getConnectionDetails();
			
			ps=con.prepareStatement("select * from userdetails");
			 rs=ps.executeQuery();
			 int count=0;
			while(rs.next())
			{
				String name=rs.getString(1);
				String psd=rs.getString(2);
			
				if(name.equals(userName) && psd.equals(password))
				{
					System.out.println("you can add");
					PreparedStatement ps2=con.prepareStatement("select * from productdetails");
					ResultSet rs2=ps2.executeQuery();
					System.out.printf("%20s %20s %20s %20s %20s ", "prouductId", "description", "price", "name", "quantity");
					while(rs2.next())
					{
						System.out.println();
					    System.out.println("------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%20d %20s %20s %20s %20d", rs2.getInt(1), rs2.getString(2), rs2.getDouble(3), 
						rs2.getString(4), rs2.getInt(5));
						System.out.println();
					}
					
					
					count=1;
				}
				
			}
			if(count==0)
			{
				System.out.println("Invalid Username or Password");
				System.exit(count);
				
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			ps.close();
			rs.close();
		}
	}
		public void addTocart()
		{
			Connection con=null;
			PreparedStatement ps=null;
			Scanner sc =new Scanner(System.in);
			ResultSet rs=null;
				try {
					BuyProduct.buyProduct(userName, password);
					ConnectionTest connectionTest=new ConnectionTest();
					con=connectionTest.getConnectionDetails();
					PreparedStatement ps2=con.prepareStatement("create table "+userName+"(prouductId int primary key not null ,description varchar(40), price double, name varchar(40), quantity int, foreign key (prouductId) references productdetails (prouductId));");
					//PreparedStatement ps2=con.prepareStatement("create table "+userName+ " (no int);");
				
					int i=ps2.executeUpdate();
					//System.out.println(i);
					char ch1 = 'y';
					while(ch1=='y')
					{
					System.out.println("Which Product Do You Want To Add: ");
					System.out.println("Pls Enter Product Id: ");
					int id=sc.nextInt();
					System.out.println("pls Enter Quantity: ");
					int quantity=sc.nextInt();
				
					ps=con.prepareStatement("select prouductId from shoppingcart.productdetails;");
					 rs=ps.executeQuery();
					 while(rs.next())
						{
							int pid=rs.getInt(1);
							if(pid==id)
							{
							PreparedStatement ps1=con.prepareStatement("insert into "+userName+" select prouductId,description,price,name,"+quantity+" from productdetails where prouductId = ?;");
							//ps1.setString(1,userName);
							ps1.setInt(1, pid);
							int i1=ps1.executeUpdate();
							//System.out.println("i="+i1);
							}
							//String psd=rs.getString(2);
						}
					 System.out.println("If you want to add more Products then press 'y': else press any key:");
						 ch1=sc.next().charAt(0);
					}
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
	public static void main(String[] args) throws SQLException ,NullPointerException{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		int c=0;
		while(c==0)
		{
			System.out.println("1. Registration Page");
			System.out.println("2. Login Page");
			System.out.println("3. User  Page");
			System.out.println("4. Admin Page");
			System.out.println("5. User History Page");
			System.out.println("6. User Details ");
			System.out.println("Enter the choice:");
			int ch=sc.nextInt();
		switch(ch)
		{
			case 1://registration
				
				try {
					System.out.println("***Registration***");
					System.out.println("**User Details**");
					System.out.println("Enter the User Name: ");
				
					String userName1=sc.next();
					
					System.out.println("Enter the Password: ");
					String password1=sc.next();
					UserPage userPage =new UserPage();
					userPage.insertUserDetails(userName1, password1);
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					
				break;
				
			case 2:	//login page
				
				System.out.println("**Login Page**");
				System.out.println("Enter the User Name: ");
				//Scanner sc=new Scanner(System.in);
				userName=sc.next();
				
				System.out.println("Enter the Password: ");
				 password=sc.next();
				BuyProduct ac=new BuyProduct();
				ac.addTocart();
			break;	
			
			case 3:
				System.out.println("*user "+userName+" table*");
				UserList ul=new UserList();
				ul.userList(userName, password);
				break;
			case 4://Admin
				Admin ad=new Admin();
				ad.displayAdmin();
				break;
			case 5:
				Admin ad1=new Admin();
				System.out.println("Which User History Do You Want To Display pls Enter user Name : ");
				userName=sc.next();
				
				ad1.displayUserDetails(userName, password);
				break;
			case 6:
				System.out.println("***USER DETAILS***");
				Admin.displayUserToAdmin();
				break;
				default:
					System.out.println("wrong choice");
					c=1;
					break;
					
		}
		
		}
		
	}

}
