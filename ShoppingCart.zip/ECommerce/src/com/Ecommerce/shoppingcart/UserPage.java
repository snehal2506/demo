package com.Ecommerce.shoppingcart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class UserPage {
	Connection con=null;
	PreparedStatement ps=null;
	PreparedStatement	ps1=null;
	ResultSet rs;
	public void insertUserDetails(String userName,String password) throws SQLException,NullPointerException
	{
		
		try {
			ConnectionTest connectionTest=new ConnectionTest();
			con=connectionTest.getConnectionDetails();
			ps1=con.prepareStatement("select * from userdetails");
		 rs=ps1.executeQuery();
			 int count=0;
			while(rs.next())
			{
				String name=rs.getString(1);
				String psd=rs.getString(2);
			
				if(name.equals(userName) && psd.equals(password)) 
				{
					System.out.println("Record is already present");
					count=1;
					break;
				}
				
				
				
			
			}
			if(count==0)
			{
			ps=con.prepareStatement("insert into userdetails(userName,password)values(?,?)");
			ps.setString(1, userName);
			ps.setString(2, password);
			int i=ps.executeUpdate();
			System.out.println("Record inserted successfully"+i);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally {
			con.close();
			ps.close();
		}
	}

	
}
